## Automate Your Life with Python
🇺🇸 This repository contains scripts of my course "Automate Your Life with Python": https://www.udemy.com/course/automate-your-life-with-python/?referralCode=7FA8B361D7A92B03A8C3

You can find more free content about Python and automation on my Medium articles and YouTube videos.

- Medium: https://frank-andrade.medium.com/
- YouTube: https://www.youtube.com/c/FrankAndrade5

## Automatiza tu Vida con Python

🇪🇸 Este repositorio contiene algunos scripts "Automatiza tu Vida con Python": https://www.udemy.com/course/automatiza-tu-vida-con-python/?referralCode=F61B2EBEB2695B3D7177

Puedes encontrar más contenido de Python y automatizacion en mis articulos de Medium y videos de YouTube

- Medium (Solo contenido en inglés): https://frank-andrade.medium.com/
- YouTube: https://www.youtube.com/c/AndradeFrank/videos
