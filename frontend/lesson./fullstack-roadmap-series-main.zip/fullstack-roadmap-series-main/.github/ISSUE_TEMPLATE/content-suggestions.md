---
name: Content Suggestions
about: For you to suggest topics I might have missed
title: Enter a detailed content suggestion title
labels: enhancement
assignees: zachgoll

---

## What essential web development topic did I miss?

REPLACE: Enter the topic here

## Why do you think this is important to add to the series?

REPLACE: Enter justification for why you think this should be part of the series.  Generally, suggestions that involve specific technologies are not accepted unless that technology is widely used and critical to the skillset of a web developer
