The lesson 10 challenge is an HTML + CSS challenge from Frontend mentor.  [Here is the challenge starter link](https://www.frontendmentor.io/challenges/testimonials-grid-section-Nnw6J7Un7).

![preview](https://dev-to-uploads.s3.amazonaws.com/uploads/articles/09vdiy9stexpyrcsjtlf.jpg)

The `solution/` folder has all of the Frontend Mentor files and has an implemented solution.

