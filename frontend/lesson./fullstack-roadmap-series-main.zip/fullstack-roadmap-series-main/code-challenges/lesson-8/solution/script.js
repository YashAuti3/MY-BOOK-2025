function alertUser() {
  alert("Hey, you clicked the button!");
}
