## Welcome!

If you're coming from the "Learn JavaScript in 10 Hours (with live coding)" video, **you're in the right place!**.

This page is a quick reference for you to find all the coding challenge solutions from the video.

## Reference

* 1:42:18 - [5 beginner JavaScript challenges](https://github.com/zachgoll/fullstack-roadmap-series/tree/main/code-challenges/lesson-3)
* 2:35:59 - [5 beginner JavaScript challenges](https://github.com/zachgoll/fullstack-roadmap-series/tree/main/code-challenges/lesson-4)
* 3:51:52 - [25 beginner JavaScript challenges (Codewars)](https://www.codewars.com/collections/lesson-5-practice-challenges-number-fullstackroadmap)
* 8:36:04 - [10 beginner/intermediate JavaScript challenges (Codewars)](https://www.codewars.com/collections/lesson-6-challenges-number-fullstackroadmap)
